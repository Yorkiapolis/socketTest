UNITY_GROUP
-----------

.. versionadded:: 3.18

This property controls which *bucket* the source will be part of when
the :prop_tgt:`UNITY_BUILD_MODE` is set to ``GROUP``.
